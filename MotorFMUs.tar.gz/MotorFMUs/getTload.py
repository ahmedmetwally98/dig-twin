import csv 

def get_Tload(speed, csv_file_path):
	# Open the CSV file using the open() function in (read mode):
	with open(csv_file_path) as file:
		# open the csv file
		csv_reader = csv.reader(file)
		##############################################################
		# 		extract head fields [vin, Tload, speed_m/s]  #
		# 		row_data[0] -> Vin			     #
		# 		row_data[1] -> Tlaod			     #
		# 		row_data[2] -> speed[m/s]		     #
		##############################################################
		fields = next(csv_reader)
		for row_data in csv_reader:
			_speed = float(round(speed, 4))
			_speed_row = round(float(row_data[2]), 4)
			if _speed_row == _speed:
				return float(row_data[1])
			
		file.close()


